document.addEventListener("DOMContentLoaded", () => {
  console.log("✅ LLM JS Loaded Successfully");

  // =========================================================
  // 🔹 Main Tab Switching (AI Search / Email Tagging)
  // =========================================================
  const tabs = document.querySelectorAll(".tab");
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
    });
  });

  // =========================================================
  // 🔹 Modal Logic (for AI Search Prompts)
  // =========================================================
  const addPromptBtn = document.querySelector(".add-prompt-btn");
  const modal = document.getElementById("addPromptModal");
  const closeBtn = document.querySelector(".close-btn");
  const savePromptBtn = document.getElementById("savePromptBtn");
  const promptInput = document.getElementById("promptInput");
  const promptList = document.querySelector(".prompt-list");
  let editingPromptItem = null;

  if (addPromptBtn && modal && savePromptBtn && promptList) {
    addPromptBtn.addEventListener("click", () => {
      modal.style.display = "block";
      promptInput.value = "";
      editingPromptItem = null;
    });

    closeBtn?.addEventListener("click", () => {
      modal.style.display = "none";
      editingPromptItem = null;
    });

    window.addEventListener("click", (e) => {
      if (e.target === modal) {
        modal.style.display = "none";
        editingPromptItem = null;
      }
    });

    savePromptBtn.addEventListener("click", () => {
      const newPrompt = promptInput.value.trim();
      if (!newPrompt) {
        alert("Please enter a prompt before saving.");
        return;
      }

      if (editingPromptItem) {
        editingPromptItem.querySelector(".prompt-text").textContent = newPrompt;
        editingPromptItem = null;
        modal.style.display = "none";
        return;
      }

      const newPromptItem = document.createElement("div");
      newPromptItem.classList.add("prompt-item");
      newPromptItem.innerHTML = `
        <span class="prompt-text">${newPrompt}</span>
        <span class="menu-dots">⋯</span>
        <div class="menu-popup">
          <div class="menu-option share">📤 Share</div>
          <div class="menu-option edit">✏️ Edit</div>
          <div class="menu-option delete">🗑️ Delete</div>
        </div>
      `;
      promptList.appendChild(newPromptItem);
      modal.style.display = "none";
    });

    document.addEventListener("click", (e) => {
      const allMenus = document.querySelectorAll(".menu-popup");
      allMenus.forEach(menu => menu.classList.remove("show"));

      if (e.target.classList.contains("menu-dots")) {
        e.stopPropagation();
        e.target.nextElementSibling.classList.add("show");
      }

      if (e.target.classList.contains("share")) {
        const text = e.target.closest(".prompt-item").querySelector(".prompt-text").textContent.trim();
        navigator.clipboard.writeText(text);
        alert("Prompt copied successfully!");
      }

      if (e.target.classList.contains("edit")) {
        editingPromptItem = e.target.closest(".prompt-item");
        const currentText = editingPromptItem.querySelector(".prompt-text").textContent.trim();
        promptInput.value = currentText;
        modal.style.display = "block";
      }

      if (e.target.classList.contains("delete")) {
        e.target.closest(".prompt-item").remove();
      }
    });

    const searchInput = document.querySelector(".search-box input");
    if (searchInput) {
      document.addEventListener("dblclick", (e) => {
        const promptItem = e.target.closest(".prompt-item");
        if (promptItem) {
          const text = promptItem.querySelector(".prompt-text").textContent.trim();
          searchInput.value = text;
          searchInput.focus();
        }
      });
    }
	
	// =========================================================
	// 💬 CHAT-LIKE PROMPT SEND FUNCTIONALITY
	// =========================================================
	const sendIcon = document.querySelector(".send-icon");
	const chatOutput = document.getElementById("chatOutput");
	
	if(sendIcon && searchInput && chatOutput){
		sendIcon.addEventListener('click', () => {
			const text = searchInput.value.trim();
			if(!text) return;
			
			// Remove "empty chat" palceholder
			const emptyMsg = chatOutput.querySelector(".empty-chat");
			if(emptyMsg) emptyMsg.remove();
			
			// Add user Bubble
			const userMsg = document.createElement("div");
			userMsg.className = "chat-msg user";
			userMsg.textContent = text;
			chatOutput.appendChild(userMsg);
			searchInput.value = "";
			
			// Auto-Scroll to Bottom
			chatOutput.scrollTop = chatOutput.scrollHeight;
			
			// Simulated AI reply 
			setTimeout(() => {
				const botMsg = document.createElement("div");
				botMsg.className = "chat-msg bot";
				botMsg.textContent =  `Here’s the response for: "${text}"`;
				chatOutput.appendChild(botMsg);
				chatOutput.scrollTop =chatOutput.scrollHeight;   
			}, 600);
		});
	}
	
  }

  // =========================================================
  // 🔹 Switch Between AI Search and Email Tagging Pages
  // =========================================================
  const aiTab = document.getElementById("tab-ai");
  const emailTab = document.getElementById("tab-email");
  const headerSub = document.querySelector(".header .sub");

  if (aiTab && emailTab) {
    aiTab.addEventListener("click", () => (window.location.href = "llm-ai.html"));
    emailTab.addEventListener("click", () => (window.location.href = "llm-email.html"));

    const currentPath = window.location.pathname;
    if (currentPath.includes("llm-ai.html")) {
      aiTab.classList.add("active");
      emailTab.classList.remove("active");
      if (headerSub) headerSub.textContent = "AI Search";
    } else if (currentPath.includes("llm-email.html")) {
      emailTab.classList.add("active");
      aiTab.classList.remove("active");
      if (headerSub) headerSub.textContent = "Email Tagging – Mail box 1";
    }
  }

  // =========================================================
  // 📨 Mailbox Sub-tabs Switching (Mail box 1 / Mail box 2)
  // =========================================================
  const mailboxTabs = document.querySelectorAll(".mail-tab");
  if (mailboxTabs.length > 0) {
    mailboxTabs.forEach(tab => {
      tab.addEventListener("click", () => {
        mailboxTabs.forEach(t => t.classList.remove("active"));
        tab.classList.add("active");

        const headerSub = document.querySelector(".header .sub");
        if (tab.id === "mailbox1-tab") {
          if (headerSub) headerSub.textContent = "Email Tagging – Mail box 1";
        } else {
          if (headerSub) headerSub.textContent = "Email Tagging – Mail box 2";
        }
      });
    });
  }

  // =========================================================
  // 📬 Mail Preview Panel (Split-View, Checkbox Safe)
  // =========================================================
  const mailList = document.querySelector(".mail-list");
  const previewPanel = document.getElementById("mailPreviewPanel");
  const closePreviewBtn = document.querySelector(".close-preview");

  function openPreview(item) {
    if (!item || !previewPanel) return;

    // highlight selected mail
    document.querySelectorAll(".mail-item").forEach(m => m.classList.remove("active"));
    item.classList.add("active");

    // assign data
    const subjectEl = document.getElementById("mailSubject");
    const vendorNameEl = document.querySelector(".vendor-name");
    const vendorMailEl = document.querySelector(".vendor-mail");
    const dateEl = document.getElementById("mailDate");
    const bodyEl = document.getElementById("mailBody");
    const attachContainer = document.querySelector("#mailAttachments .attachment-list");
    const vendorIconEl = document.querySelector(".vendor-icon");

    subjectEl.textContent = item.dataset.subject || "No Subject";
    vendorNameEl.textContent = item.dataset.company || "Vendor";
    vendorMailEl.innerHTML = item.dataset.from ? `&lt;${item.dataset.from}&gt;` : "";
    dateEl.textContent = item.dataset.date || "";
    bodyEl.innerHTML = item.dataset.body || "No content available";

    const name = vendorNameEl.textContent.trim();
    vendorIconEl.textContent = name ? name.charAt(0).toUpperCase() : "V";

    attachContainer.innerHTML = "";
    if (item.dataset.attachments) {
      try {
        const attachments = JSON.parse(item.dataset.attachments);
        attachments.forEach(a => {
          const card = document.createElement("div");
          card.className = "attachment-card";
          card.innerHTML = `
            <img src="assets/${
              a.name.endsWith(".pdf")
                ? "pdf-icon.png"
                : (a.name.endsWith(".doc") || a.name.endsWith(".docx"))
                ? "doc-icon.png"
                : "xlsx-icon.png"
            }" alt="file">
            <p>${a.name}</p>
            <small>${a.size || ""}</small>
          `;
          attachContainer.appendChild(card);
        });
      } catch (err) {
        console.warn("Invalid attachment data:", err);
      }
    }

    // Show inline (no sliding animation)
    previewPanel.style.display = "block";
  }

  // Click handling (ignore checkbox)
  if (mailList) {
    mailList.addEventListener("click", (e) => {
      if (e.target.closest("input[type='checkbox']")) return;
      const item = e.target.closest(".mail-item");
      if (!item) return;
      openPreview(item);
    });
  }

  closePreviewBtn?.addEventListener("click", () => {
    // Hide the preview panel
    previewPanel.style.display = "none";

    // Expand mail list container to full width
    const mailListContainer = document.querySelector(".mail-list-container");
    if (mailListContainer) {
      mailListContainer.style.width = "100%";
      mailListContainer.style.transition = "width 0.3s ease";
    }
  });

  // =========================================================
  // 🟩 Tag / Untag Functionality
  // =========================================================
  const addBtn = document.querySelectorAll(".add-btn");
  const removeBtn = document.querySelectorAll(".remove-btn");
  const tagCountEl = document.querySelector(".tag strong");
  const untagCountEl = document.querySelector(".untag strong");

  if (tagCountEl && untagCountEl) {
    const updateCounts = () => {
      const tagged = document.querySelectorAll(".mail-item.tagged").length;
      const total = document.querySelectorAll(".mail-item").length;
      tagCountEl.textContent = tagged;
      untagCountEl.textContent = total - tagged;
    };

    addBtn.forEach(btn => {
      btn.addEventListener("click", () => {
        const checked = document.querySelectorAll(".mail-item input[type='checkbox']:checked");
        if (!checked.length) return alert("Please select at least one email to tag.");
        checked.forEach(cb => {
          cb.closest(".mail-item").classList.add("tagged");
          cb.checked = false;
        });
        updateCounts();
      });
    });

    removeBtn.forEach(btn => {
      btn.addEventListener("click", () => {
        const checked = document.querySelectorAll(".mail-item input[type='checkbox']:checked");
        if (!checked.length) return alert("Please select at least one email to untag.");
        checked.forEach(cb => {
          cb.closest(".mail-item").classList.remove("tagged");
          cb.checked = false;
        });
        updateCounts();
      });
    });

    updateCounts();
  }

  // =========================================================
  // ✅ Ensure Proper Active Tab on Load
  // =========================================================
  const path = window.location.pathname;
  if (path.includes("llm-ai.html")) {
    aiTab?.classList.add("active");
    emailTab?.classList.remove("active");
    if (headerSub) headerSub.textContent = "AI Search";
  } else if (path.includes("llm-email.html")) {
    emailTab?.classList.add("active");
    aiTab?.classList.remove("active");
    if (headerSub) headerSub.textContent = "Email Tagging – Mail box 1";
  }
});
