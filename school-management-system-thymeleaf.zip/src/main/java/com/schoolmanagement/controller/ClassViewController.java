package com.schoolmanagement.controller;

import com.schoolmanagement.entity.ClassRoom;
import com.schoolmanagement.service.ClassRoomService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/classes")
public class ClassViewController {
    private final ClassRoomService service;
    public ClassViewController(ClassRoomService service) { this.service = service; }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("classes", service.getAllClasses());
        model.addAttribute("newClass", new ClassRoom());
        return "classes";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute("newClass") ClassRoom c) {
        service.addClass(c);
        return "redirect:/classes";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.deleteClass(id);
        return "redirect:/classes";
    }
}