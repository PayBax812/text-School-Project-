package com.schoolmanagement.controller;

import com.schoolmanagement.entity.Student;
import com.schoolmanagement.service.StudentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/students")
public class StudentViewController {
    private final StudentService service;
    public StudentViewController(StudentService service) { this.service = service; }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("students", service.getAllStudents());
        model.addAttribute("newStudent", new Student());
        return "students";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute("newStudent") Student s) {
        service.addStudent(s);
        return "redirect:/students";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.deleteStudent(id);
        return "redirect:/students";
    }
}