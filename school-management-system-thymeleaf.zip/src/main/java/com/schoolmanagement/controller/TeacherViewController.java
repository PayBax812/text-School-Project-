package com.schoolmanagement.controller;

import com.schoolmanagement.entity.Teacher;
import com.schoolmanagement.service.TeacherService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/teachers")
public class TeacherViewController {
    private final TeacherService service;
    public TeacherViewController(TeacherService service) { this.service = service; }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("teachers", service.getAllTeachers());
        model.addAttribute("newTeacher", new Teacher());
        return "teachers";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute("newTeacher") Teacher t) {
        service.addTeacher(t);
        return "redirect:/teachers";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.deleteTeacher(id);
        return "redirect:/teachers";
    }
}