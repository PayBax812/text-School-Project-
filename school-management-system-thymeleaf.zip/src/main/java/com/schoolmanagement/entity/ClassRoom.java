package com.schoolmanagement.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class ClassRoom {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String className;
}