package com.schoolmanagement.service;

import com.schoolmanagement.entity.ClassRoom;
import com.schoolmanagement.repository.ClassRoomRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ClassRoomService {
    private final ClassRoomRepository repo;
    public ClassRoomService(ClassRoomRepository repo) { this.repo = repo; }
    public List<ClassRoom> getAllClasses() { return repo.findAll(); }
    public ClassRoom addClass(ClassRoom c) { return repo.save(c); }
    public void deleteClass(Long id) { repo.deleteById(id); }
}