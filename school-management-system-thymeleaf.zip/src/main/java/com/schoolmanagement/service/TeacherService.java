package com.schoolmanagement.service;

import com.schoolmanagement.entity.Teacher;
import com.schoolmanagement.repository.TeacherRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TeacherService {
    private final TeacherRepository repo;
    public TeacherService(TeacherRepository repo) { this.repo = repo; }
    public List<Teacher> getAllTeachers() { return repo.findAll(); }
    public Teacher addTeacher(Teacher t) { return repo.save(t); }
    public void deleteTeacher(Long id) { repo.deleteById(id); }
}