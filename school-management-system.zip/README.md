School Management System - Spring Boot (Ready to import)

Defaults:
- Database: MySQL
- DB name: schooldb
- DB user: root
- DB password: 1234
- Java 17, Spring Boot 3.x

Steps to run:
1. Create a database named `schooldb` in your local MySQL:
   CREATE DATABASE schooldb;
2. Update credentials in src/main/resources/application.properties if needed.
3. Import the project in IntelliJ as a Maven project.
4. Run mvn spring-boot:run or run SchoolManagementApplication.java
5. APIs are available at http://localhost:8080/api/...

Notes:
- This project uses Lombok. Install Lombok plugin in your IDE or remove Lombok annotations and add getters/setters.
