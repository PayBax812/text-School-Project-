package com.schoolmanagement.controller;

import com.schoolmanagement.entity.Attendance;
import com.schoolmanagement.service.AttendanceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/attendance")
public class AttendanceController {
    private final AttendanceService service;
    public AttendanceController(AttendanceService service){ this.service = service; }

    @GetMapping public List<Attendance> all(){ return service.getAll(); }
    @GetMapping("/{id}") public ResponseEntity<Attendance> get(@PathVariable Long id){
        return service.getById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping public Attendance create(@RequestBody Attendance a){ return service.save(a); }
    @PutMapping("/{id}") public ResponseEntity<Attendance> update(@PathVariable Long id, @RequestBody Attendance a){
        return service.getById(id).map(existing->{ a.setId(id); return ResponseEntity.ok(service.save(a)); }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){ service.delete(id); }
}
