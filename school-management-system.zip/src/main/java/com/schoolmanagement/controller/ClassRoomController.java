package com.schoolmanagement.controller;

import com.schoolmanagement.entity.ClassRoom;
import com.schoolmanagement.service.ClassRoomService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/classes")
public class ClassRoomController {
    private final ClassRoomService service;
    public ClassRoomController(ClassRoomService service){ this.service = service; }

    @GetMapping public List<ClassRoom> all(){ return service.getAll(); }
    @GetMapping("/{id}") public ResponseEntity<ClassRoom> get(@PathVariable Long id){
        return service.getById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping public ClassRoom create(@RequestBody ClassRoom c){ return service.save(c); }
    @PutMapping("/{id}") public ResponseEntity<ClassRoom> update(@PathVariable Long id, @RequestBody ClassRoom c){
        return service.getById(id).map(e->{ c.setId(id); return ResponseEntity.ok(service.save(c));}).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){ service.delete(id); }
}
