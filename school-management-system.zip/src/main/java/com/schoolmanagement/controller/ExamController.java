package com.schoolmanagement.controller;

import com.schoolmanagement.entity.Exam;
import com.schoolmanagement.service.ExamService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/exams")
public class ExamController {
    private final ExamService service;
    public ExamController(ExamService service){ this.service = service; }

    @GetMapping public List<Exam> all(){ return service.getAll(); }
    @GetMapping("/{id}") public ResponseEntity<Exam> get(@PathVariable Long id){
        return service.getById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping public Exam create(@RequestBody Exam e){ return service.save(e); }
    @PutMapping("/{id}") public ResponseEntity<Exam> update(@PathVariable Long id, @RequestBody Exam e){
        return service.getById(id).map(existing->{ e.setId(id); return ResponseEntity.ok(service.save(e)); }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){ service.delete(id); }
}
