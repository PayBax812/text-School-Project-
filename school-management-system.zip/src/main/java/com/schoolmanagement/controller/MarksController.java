package com.schoolmanagement.controller;

import com.schoolmanagement.entity.Marks;
import com.schoolmanagement.service.MarksService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/marks")
public class MarksController {
    private final MarksService service;
    public MarksController(MarksService service){ this.service = service; }

    @GetMapping public List<Marks> all(){ return service.getAll(); }
    @GetMapping("/{id}") public ResponseEntity<Marks> get(@PathVariable Long id){
        return service.getById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping public Marks create(@RequestBody Marks m){ return service.save(m); }
    @PutMapping("/{id}") public ResponseEntity<Marks> update(@PathVariable Long id, @RequestBody Marks m){
        return service.getById(id).map(existing->{ m.setId(id); return ResponseEntity.ok(service.save(m)); }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){ service.delete(id); }
}
