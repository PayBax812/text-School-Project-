package com.schoolmanagement.controller;

import com.schoolmanagement.entity.Subject;
import com.schoolmanagement.service.SubjectService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/subjects")
public class SubjectController {
    private final SubjectService service;
    public SubjectController(SubjectService service){ this.service = service; }

    @GetMapping public List<Subject> all(){ return service.getAll(); }
    @GetMapping("/{id}") public ResponseEntity<Subject> get(@PathVariable Long id){
        return service.getById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping public Subject create(@RequestBody Subject s){ return service.save(s); }
    @PutMapping("/{id}") public ResponseEntity<Subject> update(@PathVariable Long id, @RequestBody Subject s){
        return service.getById(id).map(e->{ s.setId(id); return ResponseEntity.ok(service.save(s));}).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){ service.delete(id); }
}
