package com.schoolmanagement.controller;

import com.schoolmanagement.entity.Teacher;
import com.schoolmanagement.service.TeacherService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/teachers")
public class TeacherController {
    private final TeacherService service;
    public TeacherController(TeacherService service){ this.service = service; }

    @GetMapping public List<Teacher> all(){ return service.getAll(); }
    @GetMapping("/{id}") public ResponseEntity<Teacher> get(@PathVariable Long id){
        return service.getById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping public Teacher create(@RequestBody Teacher t){ return service.save(t); }
    @PutMapping("/{id}") public ResponseEntity<Teacher> update(@PathVariable Long id, @RequestBody Teacher t){
        return service.getById(id).map(e->{ t.setId(id); return ResponseEntity.ok(service.save(t));}).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){ service.delete(id); }
}
