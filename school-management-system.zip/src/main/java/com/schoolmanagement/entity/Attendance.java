package com.schoolmanagement.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Attendance {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String date;
    private boolean present;

    @ManyToOne
    private Student student;

    @ManyToOne
    private Subject subject;
}
