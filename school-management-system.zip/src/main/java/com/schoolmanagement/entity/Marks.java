package com.schoolmanagement.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Marks {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int marksObtained;

    @ManyToOne
    private Student student;

    @ManyToOne
    private Exam exam;
}
