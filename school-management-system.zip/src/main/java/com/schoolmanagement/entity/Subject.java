package com.schoolmanagement.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Subject {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @ManyToOne
    private Teacher teacher;

    @ManyToOne
    private ClassRoom classRoom;
}
