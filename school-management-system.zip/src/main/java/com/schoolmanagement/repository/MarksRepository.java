package com.schoolmanagement.repository;

import com.schoolmanagement.entity.Marks;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MarksRepository extends JpaRepository<Marks, Long> {}
