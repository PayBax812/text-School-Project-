package com.schoolmanagement.service;

import com.schoolmanagement.entity.Attendance;
import com.schoolmanagement.repository.AttendanceRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AttendanceService {
    private final AttendanceRepository repo;
    public AttendanceService(AttendanceRepository repo){ this.repo = repo; }
    public List<Attendance> getAll(){ return repo.findAll(); }
    public Optional<Attendance> getById(Long id){ return repo.findById(id); }
    public Attendance save(Attendance a){ return repo.save(a); }
    public void delete(Long id){ repo.deleteById(id); }
}
