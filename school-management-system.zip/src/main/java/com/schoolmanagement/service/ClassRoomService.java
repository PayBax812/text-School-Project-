package com.schoolmanagement.service;

import com.schoolmanagement.entity.ClassRoom;
import com.schoolmanagement.repository.ClassRoomRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClassRoomService {
    private final ClassRoomRepository repo;
    public ClassRoomService(ClassRoomRepository repo){ this.repo = repo; }
    public List<ClassRoom> getAll(){ return repo.findAll(); }
    public Optional<ClassRoom> getById(Long id){ return repo.findById(id); }
    public ClassRoom save(ClassRoom c){ return repo.save(c); }
    public void delete(Long id){ repo.deleteById(id); }
}
