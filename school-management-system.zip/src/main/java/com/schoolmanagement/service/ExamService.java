package com.schoolmanagement.service;

import com.schoolmanagement.entity.Exam;
import com.schoolmanagement.repository.ExamRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ExamService {
    private final ExamRepository repo;
    public ExamService(ExamRepository repo){ this.repo = repo; }
    public List<Exam> getAll(){ return repo.findAll(); }
    public Optional<Exam> getById(Long id){ return repo.findById(id); }
    public Exam save(Exam e){ return repo.save(e); }
    public void delete(Long id){ repo.deleteById(id); }
}
