package com.schoolmanagement.service;

import com.schoolmanagement.entity.Marks;
import com.schoolmanagement.repository.MarksRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MarksService {
    private final MarksRepository repo;
    public MarksService(MarksRepository repo){ this.repo = repo; }
    public List<Marks> getAll(){ return repo.findAll(); }
    public Optional<Marks> getById(Long id){ return repo.findById(id); }
    public Marks save(Marks m){ return repo.save(m); }
    public void delete(Long id){ repo.deleteById(id); }
}
