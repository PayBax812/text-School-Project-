package com.schoolmanagement.service;

import com.schoolmanagement.entity.Subject;
import com.schoolmanagement.repository.SubjectRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SubjectService {
    private final SubjectRepository repo;
    public SubjectService(SubjectRepository repo){ this.repo = repo; }
    public List<Subject> getAll(){ return repo.findAll(); }
    public Optional<Subject> getById(Long id){ return repo.findById(id); }
    public Subject save(Subject s){ return repo.save(s); }
    public void delete(Long id){ repo.deleteById(id); }
}
