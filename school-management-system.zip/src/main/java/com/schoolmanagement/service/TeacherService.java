package com.schoolmanagement.service;

import com.schoolmanagement.entity.Teacher;
import com.schoolmanagement.repository.TeacherRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TeacherService {
    private final TeacherRepository repo;
    public TeacherService(TeacherRepository repo){ this.repo = repo; }
    public List<Teacher> getAll(){ return repo.findAll(); }
    public Optional<Teacher> getById(Long id){ return repo.findById(id); }
    public Teacher save(Teacher t){ return repo.save(t); }
    public void delete(Long id){ repo.deleteById(id); }
}
